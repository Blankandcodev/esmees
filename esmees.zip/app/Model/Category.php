<?php
class Category extends AppModel {
    public $actsAs = array('Tree');
}