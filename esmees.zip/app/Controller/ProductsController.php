<?php class ProductsController extends AppController {
	var $uses = array('User');
	var $helpers = array('Form', 'Country');
	var $components = array('Session');
	var $layout = 'default';
	
    public function beforeFilter(){
		parent::beforeFilter();
    }
	
    public function index() {
    }
	
    public function add(){
		
    }
}