<?php class CategoriesController extends AppController {
	var $uses = array('Category');
	
    public function index() {
		$data['Category']['parent_id'] = 2;
		$data['Category']['name'] = 'Shirts';
		//$this->Category->save($data);
		
        $data = $this->Category->find('threaded');
        $this->set('categories', $data);
    }
}